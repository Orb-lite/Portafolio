# Fish Feeder - Fullscreen Standalone Edition

Version independiente del juego en pantalla completa (100vw x 100dvh), sin portafolio ni paginas externas.

## Opcion 1: Ejecutar o desplegar como proyecto Vite / Node (con package.json)
1. Descomprime este .zip
2. Instala dependencias:
   npm install
3. Inicia en desarrollo:
   npm run dev
4. O compila para produccion (genera carpeta dist/):
   npm run build

Compatible directo con Vercel, Netlify, GitHub, Cloudflare Pages y AI Studio.

## Opcion 2: Abrir ya compilado (sin npm)
Dentro de la carpeta `play-offline/` ya viene compilado `index.html` listo para servir en S3 / hosting estatico o probar en navegador.
