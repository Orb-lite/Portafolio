import React, { useEffect, useState } from 'react';
import confetti from 'canvas-confetti';
import { GameVersion } from '../../game/types';
import { GameLanguage, GAME_TEXT } from '../../game/localization';
import {
  Sparkles,
  Map,
  RotateCcw,
  Clock3,
  Play,
  CircleDollarSign,
  ArrowRight,
  Heart,
  ChevronDown,
  ChevronUp,
  Coins,
} from 'lucide-react';
import { DownloadGameInvite } from './DownloadGameInvite';
import { formatLifeCountdown } from '../../game/lives';

interface GameResultModalProps {
  type: 'win' | 'die';
  version: GameVersion;
  language: GameLanguage;
  level: number;
  frontierLevel?: number;
  timeElapsed?: number;
  totalTiles?: number;
  xpEarned?: number;
  lives?: number;
  maxLives?: number;
  nextLifeAt?: number | null;
  adProgress?: number;
  adsPerLife?: number;
  adsReady?: boolean;
  now?: number;
  adMessage?: string;
  onNextLevel?: () => void;
  onRetry?: () => void;
  onRestart?: () => void;
  onBackToPath?: () => void;
  onJumpToFrontier?: () => void;
  onWatchAd?: () => void;
}

/* -------------------------------------------------------------
 * Decorative Iridescent 3D Pearl Component
 * -----------------------------------------------------------*/
const Pearl: React.FC<{
  className?: string;
  size?: number;
  tint?: 'lavender' | 'cyan' | 'pink' | 'white' | 'gold';
}> = ({ className = '', size = 20, tint = 'white' }) => {
  const tintGradient = (() => {
    switch (tint) {
      case 'lavender':
        return 'from-purple-200 via-fuchsia-300 to-indigo-400';
      case 'cyan':
        return 'from-cyan-100 via-sky-200 to-teal-400';
      case 'pink':
        return 'from-rose-100 via-pink-200 to-rose-400';
      case 'gold':
        return 'from-amber-100 via-yellow-200 to-amber-400';
      default:
        return 'from-white via-slate-100 to-slate-300';
    }
  })();

  return (
    <div
      style={{ width: size, height: size }}
      className={`rounded-full bg-gradient-to-br ${tintGradient} shadow-[0_4px_12px_rgba(0,0,0,0.25),0_0_10px_rgba(255,255,255,0.7)_inset] border border-white/80 relative pointer-events-none select-none ${className}`}
    >
      <div className="absolute top-[15%] left-[20%] w-[35%] h-[35%] rounded-full bg-white/90 blur-[0.3px]" />
    </div>
  );
};

/* -------------------------------------------------------------
 * Decorative 3D Golden Star with bevel & glossy shine
 * -----------------------------------------------------------*/
const GlossyStar: React.FC<{
  size?: number;
  rotate?: number;
  scale?: number;
  glow?: boolean;
}> = ({ size = 64, rotate = 0, scale = 1, glow = false }) => {
  return (
    <div
      style={{
        width: size,
        height: size,
        transform: `rotate(${rotate}deg) scale(${scale})`,
      }}
      className={`relative inline-flex items-center justify-center transition-transform pointer-events-none select-none ${
        glow ? 'filter drop-shadow-[0_0_22px_rgba(251,191,36,0.85)]' : 'filter drop-shadow-[0_6px_14px_rgba(0,0,0,0.35)]'
      }`}
    >
      <svg viewBox="0 0 100 100" className="w-full h-full">
        <defs>
          <linearGradient id="starGradFront" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffea75" />
            <stop offset="45%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#d97706" />
          </linearGradient>
          <linearGradient id="starGradBorder" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" />
            <stop offset="50%" stopColor="#fde047" />
            <stop offset="100%" stopColor="#b45309" />
          </linearGradient>
          <radialGradient id="starGloss" cx="35%" cy="30%" r="50%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.8" />
            <stop offset="50%" stopColor="#ffffff" stopOpacity="0" />
          </radialGradient>
        </defs>
        <polygon
          points="50,6 64,36 97,38 72,62 80,95 50,77 20,95 28,62 3,38 36,36"
          fill="url(#starGradFront)"
          stroke="url(#starGradBorder)"
          strokeWidth="5"
          strokeLinejoin="round"
        />
        <polygon
          points="50,14 61,38 87,40 67,58 73,83 50,69 27,83 33,58 13,40 39,38"
          fill="url(#starGloss)"
        />
        <circle cx="43" cy="35" r="5.5" fill="#ffffff" opacity="0.65" filter="blur(0.4px)" />
      </svg>
    </div>
  );
};

/* -------------------------------------------------------------
 * Decorative Golden Coin with Star Emboss
 * -----------------------------------------------------------*/
const StarCoin: React.FC<{ size?: number; className?: string }> = ({ size = 28, className = '' }) => {
  return (
    <div
      style={{ width: size, height: size }}
      className={`rounded-full bg-gradient-to-br from-amber-200 via-amber-400 to-yellow-600 border-2 border-amber-100 shadow-[0_4px_10px_rgba(0,0,0,0.3),0_0_8px_rgba(253,224,71,0.5)] flex items-center justify-center relative pointer-events-none select-none ${className}`}
    >
      <span className="text-amber-950 font-black text-[11px] drop-shadow-[0_1px_1px_rgba(255,255,255,0.6)]">★</span>
      <div className="absolute top-0.5 left-1 w-2 h-1 rounded-full bg-white/70 blur-[0.3px]" />
    </div>
  );
};

/* -------------------------------------------------------------
 * Cute Sad Orange Fish Mascot (Grande en 190px)
 * -----------------------------------------------------------*/
const SadFishMascot: React.FC<{ size?: number }> = ({ size = 190 }) => {
  return (
    <div
      style={{ width: size, height: size }}
      className="relative flex items-center justify-center pointer-events-none select-none filter drop-shadow-[0_8px_18px_rgba(0,0,0,0.35)]"
    >
      <svg viewBox="0 0 120 120" className="w-full h-full overflow-visible">
        <defs>
          <radialGradient id="fishBodyGrad" cx="40%" cy="35%" r="65%">
            <stop offset="0%" stopColor="#ffb347" />
            <stop offset="55%" stopColor="#ff7a29" />
            <stop offset="100%" stopColor="#e64a19" />
          </radialGradient>
          <linearGradient id="fishBellyGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#fff275" />
            <stop offset="100%" stopColor="#ffb300" />
          </linearGradient>
          <linearGradient id="finGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ff9800" />
            <stop offset="100%" stopColor="#d84315" />
          </linearGradient>
        </defs>

        <path
          d="M 92 60 C 105 45 118 42 116 55 C 114 62 108 65 116 75 C 117 84 105 82 92 66 Z"
          fill="url(#finGrad)"
          stroke="#bf360c"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />

        <path
          d="M 50 28 C 55 12 70 14 78 26 C 72 26 62 26 50 28 Z"
          fill="url(#finGrad)"
          stroke="#bf360c"
          strokeWidth="2.5"
          strokeLinejoin="round"
        />

        <ellipse
          cx="60"
          cy="62"
          rx="38"
          ry="34"
          fill="url(#fishBodyGrad)"
          stroke="#bf360c"
          strokeWidth="3"
        />

        <path
          d="M 38 72 C 45 88 75 88 84 72 C 72 78 50 78 38 72 Z"
          fill="url(#fishBellyGrad)"
          opacity="0.75"
        />

        <ellipse cx="48" cy="42" rx="12" ry="5" fill="#ffffff" opacity="0.45" transform="rotate(-15 48 42)" />

        <g>
          <path d="M 40 47 Q 46 44 50 49" stroke="#792900" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          <ellipse cx="45" cy="56" rx="5.5" ry="6.5" fill="#2d1500" />
          <circle cx="43.5" cy="53.5" r="2.2" fill="#ffffff" />
          <circle cx="47" cy="58.5" r="1.1" fill="#ffffff" />
        </g>

        <g>
          <path d="M 64 49 Q 68 44 74 47" stroke="#792900" strokeWidth="2.5" strokeLinecap="round" fill="none" />
          <ellipse cx="69" cy="56" rx="5.5" ry="6.5" fill="#2d1500" />
          <circle cx="67.5" cy="53.5" r="2.2" fill="#ffffff" />
          <circle cx="71" cy="58.5" r="1.1" fill="#ffffff" />
        </g>

        <path
          d="M 52 74 Q 57 69 62 74"
          stroke="#5d1c00"
          strokeWidth="3"
          strokeLinecap="round"
          fill="none"
        />

        <path
          d="M 30 68 C 22 72 20 80 26 84 C 30 82 32 76 33 70 Z"
          fill="url(#finGrad)"
          stroke="#bf360c"
          strokeWidth="2"
        />

        <path
          d="M 40 64 C 40 68 44 68 44 64 C 44 62 42 60 42 60 C 42 60 40 62 40 64 Z"
          fill="#67e8f9"
          stroke="#0891b2"
          strokeWidth="1"
          opacity="0.85"
        />
      </svg>
    </div>
  );
};

/* -------------------------------------------------------------
 * 3D Sad Black Tile (Ficha Negra con cara triste) for Tile Absorber
 * -----------------------------------------------------------*/
const SadBlackTile: React.FC<{
  size?: number;
  rotate?: number;
  scale?: number;
  glow?: boolean;
  expression?: 'crying' | 'worried' | 'sobbing';
}> = ({ size = 72, rotate = 0, scale = 1, glow = false, expression = 'crying' }) => {
  return (
    <div
      style={{
        width: size,
        height: size,
        transform: `rotate(${rotate}deg) scale(${scale})`,
      }}
      className={`relative inline-flex items-center justify-center transition-transform pointer-events-none select-none ${
        glow
          ? 'filter drop-shadow-[0_10px_24px_rgba(56,189,248,0.35)] drop-shadow-[0_4px_12px_rgba(0,0,0,0.7)]'
          : 'filter drop-shadow-[0_8px_16px_rgba(0,0,0,0.6)]'
      }`}
    >
      <svg viewBox="0 0 100 100" className="w-full h-full overflow-visible">
        <defs>
          <linearGradient id="tileDarkBorderGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#94a3b8" />
            <stop offset="40%" stopColor="#475569" />
            <stop offset="100%" stopColor="#0f172a" />
          </linearGradient>
          <linearGradient id="tileDarkBodyGrad" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="#334155" />
            <stop offset="35%" stopColor="#1e293b" />
            <stop offset="75%" stopColor="#0f172a" />
            <stop offset="100%" stopColor="#020617" />
          </linearGradient>
          <linearGradient id="tileDarkGlossGrad" x1="0%" y1="0%" x2="0%" y2="100%">
            <stop offset="0%" stopColor="#ffffff" stopOpacity="0.4" />
            <stop offset="55%" stopColor="#ffffff" stopOpacity="0.08" />
            <stop offset="100%" stopColor="#ffffff" stopOpacity="0" />
          </linearGradient>
          <radialGradient id="tileDarkTearGrad" cx="35%" cy="30%" r="70%">
            <stop offset="0%" stopColor="#bae6fd" />
            <stop offset="60%" stopColor="#38bdf8" />
            <stop offset="100%" stopColor="#0284c7" />
          </radialGradient>
        </defs>

        {/* 3D Base Tile Body (Beveled Rounded Square) */}
        <rect
          x="8"
          y="10"
          width="84"
          height="84"
          rx="22"
          fill="url(#tileDarkBorderGrad)"
          stroke="#cbd5e1"
          strokeWidth="1.5"
          strokeOpacity="0.5"
        />
        <rect
          x="12"
          y="12"
          width="76"
          height="76"
          rx="18"
          fill="url(#tileDarkBodyGrad)"
        />

        {/* Gloss reflection arc on top */}
        <path
          d="M 18 20 C 35 14 65 14 82 20 C 78 36 60 40 50 40 C 40 40 22 36 18 20 Z"
          fill="url(#tileDarkGlossGrad)"
        />

        {/* Top Rim Highlight Specular Line */}
        <path
          d="M 28 14 Q 50 12 72 14"
          stroke="#ffffff"
          strokeWidth="2.5"
          strokeLinecap="round"
          strokeOpacity="0.8"
        />

        {/* Facial Expressions */}
        {expression === 'crying' && (
          <g>
            {/* Worried curved eyebrows */}
            <path d="M 28 36 Q 36 32 42 37" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <path d="M 72 36 Q 64 32 58 37" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" fill="none" />

            {/* Left Big Sad Eye */}
            <ellipse cx="36" cy="48" rx="7" ry="8" fill="#020617" stroke="#64748b" strokeWidth="1" />
            <ellipse cx="35" cy="46" rx="5" ry="6" fill="#0f172a" />
            <circle cx="34" cy="44" r="2.8" fill="#ffffff" />
            <circle cx="38" cy="49" r="1.3" fill="#ffffff" />

            {/* Right Big Sad Eye */}
            <ellipse cx="64" cy="48" rx="7" ry="8" fill="#020617" stroke="#64748b" strokeWidth="1" />
            <ellipse cx="65" cy="46" rx="5" ry="6" fill="#0f172a" />
            <circle cx="63" cy="44" r="2.8" fill="#ffffff" />
            <circle cx="67" cy="49" r="1.3" fill="#ffffff" />

            {/* Rosy Blush on Dark Cheeks */}
            <ellipse cx="26" cy="55" rx="5" ry="2.5" fill="#f43f5e" opacity="0.45" />
            <ellipse cx="74" cy="55" rx="5" ry="2.5" fill="#f43f5e" opacity="0.45" />

            {/* Wavy quivering sad mouth */}
            <path
              d="M 43 66 Q 50 60 57 66"
              stroke="#f1f5f9"
              strokeWidth="2.8"
              strokeLinecap="round"
              fill="none"
            />

            {/* Big Shiny Teardrops */}
            <path
              d="M 26 58 C 24 64 29 69 32 66 C 34 63 31 58 28 53 C 27 55 26 56 26 58 Z"
              fill="url(#tileDarkTearGrad)"
              filter="drop-shadow(0 2px 4px rgba(56,189,248,0.5))"
            />
            <circle cx="28.5" cy="62" r="1.2" fill="#ffffff" opacity="0.8" />

            <path
              d="M 74 58 C 76 64 71 69 68 66 C 66 63 69 58 72 53 C 73 55 74 56 74 58 Z"
              fill="url(#tileDarkTearGrad)"
              filter="drop-shadow(0 2px 4px rgba(56,189,248,0.5))"
            />
            <circle cx="71.5" cy="62" r="1.2" fill="#ffffff" opacity="0.8" />
          </g>
        )}

        {expression === 'worried' && (
          <g>
            {/* Sad downward slant brows */}
            <path d="M 30 38 Q 38 34 43 40" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" fill="none" />
            <path d="M 70 38 Q 62 34 57 40" stroke="#cbd5e1" strokeWidth="2.5" strokeLinecap="round" fill="none" />

            {/* Sad drooping eyes */}
            <ellipse cx="38" cy="49" rx="6" ry="6.5" fill="#0f172a" stroke="#64748b" strokeWidth="1" />
            <circle cx="36" cy="47" r="2.2" fill="#ffffff" />
            <circle cx="39.5" cy="51" r="1" fill="#ffffff" />

            <ellipse cx="62" cy="49" rx="6" ry="6.5" fill="#0f172a" stroke="#64748b" strokeWidth="1" />
            <circle cx="60" cy="47" r="2.2" fill="#ffffff" />
            <circle cx="63.5" cy="51" r="1" fill="#ffffff" />

            {/* Blush */}
            <ellipse cx="29" cy="56" rx="4" ry="2" fill="#f43f5e" opacity="0.4" />
            <ellipse cx="71" cy="56" rx="4" ry="2" fill="#f43f5e" opacity="0.4" />

            {/* Downturned sad frown */}
            <path
              d="M 44 65 Q 50 59 56 65"
              stroke="#f1f5f9"
              strokeWidth="2.5"
              strokeLinecap="round"
              fill="none"
            />

            {/* Single small tear on left */}
            <path
              d="M 30 58 C 28 62 31 66 33 64 C 35 62 33 58 31 54 Z"
              fill="url(#tileDarkTearGrad)"
            />
          </g>
        )}

        {expression === 'sobbing' && (
          <g>
            {/* Squeezed crying eyes (> <) */}
            <path d="M 32 44 L 40 48 L 32 52" stroke="#f1f5f9" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />
            <path d="M 68 44 L 60 48 L 68 52" stroke="#f1f5f9" strokeWidth="2.8" strokeLinecap="round" strokeLinejoin="round" fill="none" />

            {/* Blush */}
            <ellipse cx="28" cy="57" rx="4.5" ry="2" fill="#f43f5e" opacity="0.45" />
            <ellipse cx="72" cy="57" rx="4.5" ry="2" fill="#f43f5e" opacity="0.45" />

            {/* Open waaaah sad mouth */}
            <path
              d="M 44 61 Q 50 71 56 61 Z"
              fill="#e11d48"
              stroke="#f1f5f9"
              strokeWidth="1.8"
              strokeLinejoin="round"
            />

            {/* Tear stream on right */}
            <path
              d="M 70 56 C 73 63 68 67 65 64 C 63 61 66 56 69 52 Z"
              fill="url(#tileDarkTearGrad)"
            />
          </g>
        )}
      </svg>
    </div>
  );
};

export const GameResultModal: React.FC<GameResultModalProps> = ({
  type,
  version,
  language = 'es',
  level,
  frontierLevel,
  timeElapsed = 0,
  totalTiles = 0,
  xpEarned = 0,
  lives = 3,
  maxLives = 3,
  nextLifeAt = null,
  adProgress = 0,
  adsPerLife = 1,
  adsReady = false,
  now = Date.now(),
  adMessage = '',
  onNextLevel,
  onRetry,
  onRestart,
  onBackToPath,
  onJumpToFrontier,
  onWatchAd,
}) => {
  const isWin = type === 'win';
  const isFoF = version === 'fof';
  const t = GAME_TEXT[language];
  const isReplay = typeof frontierLevel === 'number' && level < frontierLevel;
  const outOfLives = lives === 0;

  const [showInviteModal, setShowInviteModal] = useState(false);
  const [showStats, setShowStats] = useState(false);
  const [jackpotDisplay, setJackpotDisplay] = useState(0);

  useEffect(() => {
    if (isWin && isFoF) {
      let rafId = 0;
      const start = performance.now();
      const duration = 950;
      const step = (ts: number) => {
        const progress = Math.min(1, (ts - start) / duration);
        const eased = 1 - Math.pow(1 - progress, 3);
        setJackpotDisplay(Math.round(eased * 1000000));
        if (progress < 1) {
          rafId = requestAnimationFrame(step);
        }
      };
      rafId = requestAnimationFrame(step);
      return () => cancelAnimationFrame(rafId);
    }
    return undefined;
  }, [isWin, isFoF]);

  useEffect(() => {
    if (isWin) {
      try {
        confetti({
          particleCount: 90,
          spread: 80,
          origin: { y: 0.55 },
          colors: ['#38bdf8', '#fbbf24', '#f59e0b', '#f43f5e', '#ffffff'],
        });
        const timer = setTimeout(() => {
          confetti({
            particleCount: 45,
            angle: 60,
            spread: 55,
            origin: { x: 0.1, y: 0.6 },
          });
          confetti({
            particleCount: 45,
            angle: 120,
            spread: 55,
            origin: { x: 0.9, y: 0.6 },
          });
        }, 320);
        return () => clearTimeout(timer);
      } catch {
        // fallback
      }
    }
  }, [isWin]);

  const handleDownloadFreeClick = () => {
    const deferredPrompt = (window as unknown as { deferredPrompt?: { prompt: () => void } }).deferredPrompt;
    if (deferredPrompt) {
      try {
        deferredPrompt.prompt();
        return;
      } catch {
        // fallback
      }
    }
    setShowInviteModal(true);
  };

  const titleText = isWin
    ? (isFoF ? t.jackpotLabel : t.winTitleConveyor)
    : (isFoF ? t.loseTitleFof : t.loseTitleConveyor);

  const subtitleText = isWin
    ? (isFoF ? t.winSubtextFof : t.winSubtextConveyor)
    : (isFoF ? t.loseSubtextFof : t.loseSubtextConveyor);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="game-result-title"
      className={`fixed inset-0 z-50 flex items-center justify-center p-3 sm:p-6 ${
        isFoF && isWin ? 'bg-sky-950/75' : 'bg-slate-950/80'
      } animate-in fade-in duration-300 select-none overflow-y-auto`}
    >
      <div className="relative w-full max-w-lg my-auto pt-14 sm:pt-16 pb-3">
        {/* Decorative Floating Pearls around the card */}
        <Pearl size={22} tint="lavender" className="absolute top-10 -left-2 sm:-left-4 z-20" />
        <Pearl size={16} tint="cyan" className="absolute top-24 left-4 z-20 opacity-85" />
        <Pearl size={26} tint="white" className="absolute top-1/2 -left-3 sm:-left-5 z-20 shadow-cyan-500/50" />
        <Pearl size={18} tint="pink" className="absolute bottom-16 -left-1 sm:-left-3 z-20" />
        <Pearl size={20} tint="cyan" className="absolute -bottom-2 left-8 z-20" />

        <Pearl size={20} tint="lavender" className="absolute top-12 -right-2 sm:-right-4 z-20" />
        <Pearl size={24} tint="cyan" className="absolute top-26 -right-3 sm:-right-5 z-20" />
        <Pearl size={26} tint="white" className="absolute top-2/3 -right-3 sm:-right-5 z-20" />
        <Pearl size={16} tint="pink" className="absolute bottom-20 right-4 z-20" />
        <Pearl size={18} tint="lavender" className="absolute -bottom-2 right-10 z-20" />

        {isWin && (
          <>
            <StarCoin size={32} className="absolute -top-2 right-8 sm:right-12 z-20 rotate-12" />
            <StarCoin size={28} className="absolute top-10 left-6 z-20 -rotate-12" />
            <StarCoin size={30} className="absolute bottom-24 -left-3 sm:-left-4 z-20 -rotate-12" />
            <StarCoin size={34} className="absolute bottom-8 -right-2 sm:-right-4 z-20 rotate-6" />
          </>
        )}

        {/* CARD CONTAINER */}
        <div className="relative w-full rounded-[2.5rem] sm:rounded-[3rem] border-2 border-white/80 shadow-[0_25px_65px_rgba(8,145,178,0.45)]">
          <div className="absolute inset-0 rounded-[2.5rem] sm:rounded-[3rem] overflow-hidden pointer-events-none">
            <div
              className={`absolute inset-0 ${
                isFoF
                  ? 'bg-gradient-to-b from-sky-500 via-cyan-600 to-teal-700'
                  : 'bg-slate-900 border-cyan-300/60'
              }`}
            />
            <div className="absolute top-1.5 left-10 right-10 h-3 rounded-full bg-gradient-to-b from-white/50 to-transparent" />
          </div>

          {/* Mascot / Stars Header */}
          <div className="absolute -top-12 sm:-top-14 left-1/2 -translate-x-1/2 z-30 flex items-center justify-center pointer-events-none">
            {isWin ? (
              <div className="relative flex items-end justify-center">
                <span className="absolute -top-3 left-1 text-white text-base sm:text-lg">✦</span>
                <span className="absolute -top-4 right-1 text-white text-base sm:text-lg">✦</span>
                <span className="absolute bottom-4 -left-4 text-amber-200 text-xs sm:text-sm">✧</span>
                <span className="absolute bottom-5 -right-4 text-amber-200 text-xs sm:text-sm">✧</span>

                <div className="-mr-3 sm:-mr-4 -mb-1 transform -rotate-12">
                  <GlossyStar size={68} rotate={-12} scale={0.92} />
                </div>

                <div className="z-10 -mb-2">
                  <GlossyStar size={96} rotate={0} scale={1.08} glow={true} />
                </div>

                <div className="-ml-3 sm:-ml-4 -mb-1 transform rotate-12">
                  <GlossyStar size={68} rotate={12} scale={0.92} />
                </div>
              </div>
            ) : isFoF ? (
              <div className="flex justify-center relative z-40 -top-2">
                <SadFishMascot size={150} />
              </div>
            ) : (
              <div className="relative flex items-end justify-center">
                <span className="absolute -top-3 left-1 text-sky-300 text-sm sm:text-base">💧</span>
                <span className="absolute -top-4 right-1 text-sky-300 text-sm sm:text-base">💧</span>
                <span className="absolute bottom-4 -left-4 text-slate-400 text-xs sm:text-sm">✧</span>
                <span className="absolute bottom-5 -right-4 text-slate-400 text-xs sm:text-sm">✧</span>

                <div className="-mr-3 sm:-mr-4 -mb-1 transform -rotate-12">
                  <SadBlackTile size={68} rotate={-12} scale={0.92} expression="worried" />
                </div>

                <div className="z-10 -mb-2">
                  <SadBlackTile size={96} rotate={0} scale={1.08} glow={true} expression="crying" />
                </div>

                <div className="-ml-3 sm:-ml-4 -mb-1 transform rotate-12">
                  <SadBlackTile size={68} rotate={12} scale={0.92} expression="sobbing" />
                </div>
              </div>
            )}
          </div>

          {/* Card Body */}
          <div className="relative z-10 p-5 sm:p-7 pt-12 sm:pt-14 text-center text-white">
            {isWin && isReplay && (
              <div className="inline-flex items-center gap-1.5 px-3 py-1 mb-2 rounded-full bg-white/25 border border-white/60 text-xs font-black text-amber-200 uppercase tracking-wider shadow-sm">
                <Sparkles className="w-3.5 h-3.5 text-amber-200" />
                {t.replayPastCleared}
              </div>
            )}

            {isFoF && isWin && (
              <div className="inline-flex items-center gap-2 px-4 py-1 mb-2 rounded-full bg-amber-400/25 border border-amber-200/80 text-xs font-black tracking-widest uppercase text-amber-100">
                <span>FISH FEEDER</span>
              </div>
            )}

            <h1
              id="game-result-title"
              className="text-3xl sm:text-4xl md:text-5xl font-black tracking-wide text-white drop-shadow-[0_4px_8px_rgba(0,0,0,0.3)] mt-0 mb-1.5 uppercase"
            >
              {titleText}
            </h1>

            {isFoF && isWin ? (
              <div className="my-3 py-3 px-5 rounded-3xl bg-slate-950/35 border-2 border-amber-300/80 inline-flex items-center justify-center gap-3 shadow-inner">
                <Coins className="w-7 h-7 sm:w-8 sm:h-8 text-amber-300 shrink-0" />
                <span className="text-3xl sm:text-4xl font-black text-amber-300 tracking-tight tabular-nums drop-shadow-[0_2px_6px_rgba(0,0,0,0.45)]">
                  {jackpotDisplay.toLocaleString('en-US')}
                </span>
              </div>
            ) : null}

            <p className="text-sm sm:text-base font-bold text-white/95 max-w-md mx-auto mb-5 leading-snug drop-shadow-[0_2px_4px_rgba(0,0,0,0.25)]">
              {subtitleText}
            </p>

          <div className="w-full flex justify-center mb-5">
            <button
              type="button"
              onClick={handleDownloadFreeClick}
              aria-label={isFoF && isWin ? t.playNowCta : t.downloadFree}
              className={`group relative w-full sm:w-[84%] max-w-md py-3.5 sm:py-4 px-6 rounded-full font-black text-lg sm:text-xl text-white tracking-wide border-2 border-white/90 active:scale-95 transition-all duration-150 cursor-pointer flex items-center justify-center gap-3 ${
                isFoF && isWin
                  ? 'shadow-[0_12px_28px_rgba(22,163,74,0.55),0_-3px_8px_rgba(255,255,255,0.45)_inset] bg-gradient-to-b from-lime-400 via-emerald-500 to-green-700 hover:brightness-110'
                  : 'shadow-[0_12px_28px_rgba(255,140,0,0.55),0_-3px_8px_rgba(255,255,255,0.45)_inset] bg-gradient-to-b from-[#ffbe3b] via-[#ff8d00] to-[#e65c00] hover:brightness-110'
              }`}
            >
              <div className="absolute top-1.5 left-6 right-6 h-1.5 rounded-full bg-white/50 pointer-events-none" />
              <span className="drop-shadow-[0_2px_3px_rgba(0,0,0,0.3)] font-black uppercase">
                {isFoF && isWin ? t.playNowCta : t.downloadFree}
              </span>
            </button>
          </div>

          <div className="w-full max-w-md mx-auto flex flex-col gap-2.5">
            {isWin && onNextLevel && (
              <button
                type="button"
                onClick={onNextLevel}
                className="w-full py-3 px-6 rounded-full font-black text-sm sm:text-base text-white border-2 border-white/75 bg-white/15 hover:bg-white/25 active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <span>{t.continueLevel} {level + 1}</span>
                <ArrowRight className="w-4 h-4" />
              </button>
            )}

            {!isWin && onRetry && (
              <button
                type="button"
                onClick={onRetry}
                disabled={outOfLives}
                className="w-full py-3.5 px-6 rounded-full font-black text-base sm:text-lg text-white border-2 border-white/80 shadow-[0_10px_24px_rgba(16,185,129,0.45),0_-2px_6px_rgba(255,255,255,0.4)_inset] bg-gradient-to-b from-emerald-400 via-teal-500 to-emerald-700 hover:brightness-110 disabled:opacity-50 disabled:grayscale active:scale-95 transition-all cursor-pointer flex items-center justify-center gap-2"
              >
                <RotateCcw className="w-5 h-5" />
                <span>{outOfLives ? t.outOfLives : `${t.retryLevel} ${level}`}</span>
              </button>
            )}

            {isWin && isReplay && onJumpToFrontier && frontierLevel && (
              <button
                type="button"
                onClick={onJumpToFrontier}
                className="w-full py-2.5 px-4 rounded-full font-bold text-sm text-amber-200 border border-amber-300/60 bg-white/15 hover:bg-white/25 backdrop-blur-md transition cursor-pointer flex items-center justify-center gap-2 shadow-sm"
              >
                <Sparkles className="w-4 h-4 text-amber-300" />
                <span>{t.jumpToFrontier} {frontierLevel}</span>
              </button>
            )}

            <div className="grid grid-cols-2 gap-2.5">
                {onBackToPath && (
                <button
                  type="button"
                  onClick={onBackToPath}
                  className="py-2.5 px-3 rounded-full font-bold text-xs sm:text-sm text-white border border-white/60 bg-white/20 hover:bg-white/30 active:scale-95 transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <span className="truncate">{t.returnToPathway}</span>
                </button>
              )}

              {(isWin ? onRestart : onRetry) && (
                <button
                  type="button"
                  onClick={isWin ? onRestart : onRetry}
                  className="py-2.5 px-3 rounded-full font-bold text-xs sm:text-sm text-white border border-white/60 bg-white/20 hover:bg-white/30 active:scale-95 transition cursor-pointer flex items-center justify-center gap-1.5 shadow-sm"
                >
                  <RotateCcw className="w-4 h-4 text-amber-200" />
                  <span className="truncate">{isWin ? t.replayThisLevel : t.retryLevel}</span>
                </button>
              )}
            </div>

            {!isWin && lives < maxLives && (
              <div className="mt-1 p-3 rounded-2xl bg-white/15 border border-white/30 text-left text-xs space-y-2">
                <div className="flex items-center justify-between text-white font-bold">
                  <div className="flex items-center gap-1">
                    <Heart className="w-3.5 h-3.5 fill-rose-400 text-rose-300" />
                    <span>{t.lives}: {lives}/{maxLives}</span>
                  </div>
                  <div className="flex items-center gap-1 text-cyan-200 font-mono text-[11px] tabular-nums">
                    <Clock3 className="w-3.5 h-3.5" />
                    <span>{t.nextLifeIn} {formatLifeCountdown(nextLifeAt, now)}</span>
                  </div>
                </div>

                {onWatchAd && (
                  <div className="pt-2 border-t border-white/20 flex items-center justify-between gap-2">
                    <div className="flex items-center gap-1.5 text-amber-200 text-[11px]">
                      <CircleDollarSign className="w-3.5 h-3.5 text-amber-300" />
                      <span>{t.rewardedVideo}: {adsPerLife}</span>
                    </div>
                    <button
                      type="button"
                      onClick={onWatchAd}
                      disabled={!adsReady}
                      className="px-3 py-1 rounded-full bg-gradient-to-r from-amber-400 to-yellow-300 hover:brightness-110 disabled:opacity-50 text-slate-950 font-black text-xs transition cursor-pointer flex items-center gap-1 shadow-sm"
                    >
                      <Play className="w-3 h-3 fill-slate-950" />
                      <span>{adsReady ? t.watchAd : t.adsAvailableMobile}</span>
                    </button>
                  </div>
                )}
                {adMessage && <p className="text-[11px] text-rose-200">{adMessage}</p>}
              </div>
            )}

            {isWin && (
              <div className="mt-1">
                <button
                  type="button"
                  onClick={() => setShowStats(!showStats)}
                  className="inline-flex items-center gap-1 text-xs font-semibold text-white/80 hover:text-white transition cursor-pointer"
                >
                  <span>{showStats ? (language === 'en' ? 'Hide stats' : 'Ocultar estadísticas') : (language === 'en' ? 'View stats' : 'Ver estadísticas')}</span>
                  {showStats ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
                </button>

                {showStats && (
                  <div className="grid grid-cols-3 gap-2 mt-2 p-2.5 rounded-2xl bg-white/15 border border-white/30 text-center animate-in fade-in duration-200">
                    <div>
                      <p className="text-[10px] font-semibold text-white/70 uppercase">{t.absorbedCount}</p>
                      <p className="text-base font-black text-white tabular-nums">{totalTiles}</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-semibold text-white/70 uppercase">{t.timeElapsed}</p>
                      <p className="text-base font-black text-emerald-200 tabular-nums">{timeElapsed}s</p>
                    </div>
                    <div>
                      <p className="text-[10px] font-semibold text-white/70 uppercase">{t.xpEarned}</p>
                      <p className="text-base font-black text-amber-200 tabular-nums">+{xpEarned}</p>
                    </div>
                  </div>
                )}
              </div>
            )}
          </div>

            <div className="mt-4 pt-2 border-t border-white/20 flex items-center justify-center gap-1 text-[11px] text-white/80 font-medium">
              <Sparkles className="w-3 h-3 text-amber-300" />
              <span>{`${isFoF ? 'Fish Feeder' : 'Conveyor Realms'} · ${language === 'en' ? 'By Dimpz Games' : 'Por Dimpz Games'} · Isaac Gómez`}</span>
            </div>
          </div>
        </div>
      </div>

      {showInviteModal && (
        <div className="fixed inset-0 z-60 flex items-center justify-center p-3 sm:p-4 bg-slate-950/85">
          <div className="relative w-full max-w-xl max-h-[92vh] overflow-y-auto rounded-3xl bg-slate-900 border border-cyan-400/50 p-4 sm:p-6 shadow-2xl text-left">
            <button
              type="button"
              onClick={() => setShowInviteModal(false)}
              className="absolute top-4 right-4 z-20 text-slate-400 hover:text-white p-1.5 rounded-xl bg-slate-800 hover:bg-slate-700 border border-slate-700 cursor-pointer text-xs font-bold"
            >
              ✕ {t.close}
            </button>

            <DownloadGameInvite
              context={isWin ? 'win' : 'death'}
              level={level}
              language={language}
              version={version}
              gameName={isFoF ? 'Fish Feeder' : 'Tile Absorber'}
              compact={false}
            />
          </div>
        </div>
      )}
    </div>
  );
};